# Sem título

```jsx
package com.fiapdelivery.model;

public abstract class Veiculo {
    private String placa;
    private double capacidadeCarga;

    public Veiculo(String placa, double capacidadeCarga) {
        setPlaca(placa);
        setCapacidadeCarga(capacidadeCarga);
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        if (placa == null || placa.trim().isEmpty()) {
            throw new IllegalArgumentException("A placa do veículo não pode ser vazia.");
        }
        this.placa = placa;
    }

    public double getCapacidadeCarga() {
        return capacidadeCarga;
    }

    public void setCapacidadeCarga(double capacidadeCarga) {
        if (capacidadeCarga <= 0) {
            throw new IllegalArgumentException("A capacidade de carga deve ser superior a zero.");
        }
        this.capacidadeCarga = capacidadeCarga;
    }
}

package com.fiapdelivery.model;

public class Caminhao extends Veiculo {
    private int quantidadeEixos;

    public Caminhao(String placa, double capacidadeCarga, int quantidadeEixos) {
        super(placa, capacidadeCarga);
        setQuantidadeEixos(quantidadeEixos);
    }

    public int getQuantidadeEixos() {
        return quantidadeEixos;
    }

    public void setQuantidadeEixos(int quantidadeEixos) {
        if (quantidadeEixos <= 0) {
            throw new IllegalArgumentException("A quantidade de eixos deve ser superior a zero.");
        }
        this.quantidadeEixos = quantidadeEixos;
    }
}

package com.fiapdelivery.model;

public class Moto extends Veiculo {
    private boolean temBau;

    public Moto(String placa, double capacidadeCarga, boolean temBau) {
        super(placa, capacidadeCarga);
        this.temBau = temBau;
    }

    public boolean isTemBau() {
        return temBau;
    }

    public void setTemBau(boolean temBau) {
        this.temBau = temBau;
    }
}

package com.fiapdelivery.model;

public class Pacote {
    private String codigo;
    private double peso;
    private String status;

    public Pacote(String codigo, double peso, String status) {
        setCodigo(codigo);
        setPeso(peso);
        setStatus(status);
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("O código do pacote não pode ser vazio.");
        }
        this.codigo = codigo;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        if (peso <= 0) {
            throw new IllegalArgumentException("O peso do pacote deve ser positivo.");
        }
        this.peso = peso;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        if (status == null || status.trim().isEmpty()) {
            throw new IllegalArgumentException("O status não pode ser vazio.");
        }
        this.status = status;
    }

    public void atualizarStatus(String novoStatus) {
        setStatus(novoStatus);
    }
}

package com.fiapdelivery.model;

public class Rota {
    private Pacote pacote;
    private Veiculo veiculo;

    public Rota(Pacote pacote, Veiculo veiculo) {
        setPacote(pacote);
        setVeiculo(veiculo);
    }

    public Pacote getPacote() {
        return pacote;
    }

    public void setPacote(Pacote pacote) {
        if (pacote == null) {
            throw new IllegalArgumentException("O pacote é obrigatório para a rota.");
        }
        this.pacote = pacote;
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo veiculo) {
        if (veiculo == null) {
            throw new IllegalArgumentException("O veículo é obrigatório para a rota.");
        }
        this.veiculo = veiculo;
    }

    public void iniciarEntrega() {
        System.out.println("Levando pacote " + pacote.getCodigo() + " no veículo " + veiculo.getPlaca());
    }
}

package com.fiapdelivery;

import com.fiapdelivery.model.Caminhao;
import com.fiapdelivery.model.Moto;
import com.fiapdelivery.model.Pacote;
import com.fiapdelivery.model.Rota;

public class Principal {
    public static void main(String[] args) {
        try {
            Caminhao caminhao = new Caminhao("ABC1234", 5000.0, 3);
            Pacote pacote1 = new Pacote("BR999", 10.5, "Pendente");

            Rota rotaCaminhao = new Rota(pacote1, caminhao);
            rotaCaminhao.iniciarEntrega();

            Moto moto = new Moto("XYZ9876", 50.0, true);
            Pacote pacote2 = new Pacote("BR888", 2.0, "Pendente");

            Rota rotaMoto = new Rota(pacote2, moto);
            rotaMoto.iniciarEntrega();

        } catch (IllegalArgumentException e) {
            System.err.println("Erro na validação dos dados: " + e.getMessage());
        }
    }
}
```